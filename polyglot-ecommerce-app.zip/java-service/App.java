public class App {
    public static void main(String[] args) {
        System.out.println("Java Service Running");
    }
}